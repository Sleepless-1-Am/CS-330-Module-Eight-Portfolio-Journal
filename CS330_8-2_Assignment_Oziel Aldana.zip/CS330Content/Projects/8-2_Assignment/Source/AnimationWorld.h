#pragma once

#include <array>
#include <cstddef>
#include <cstdint>
#include <random>
#include <vector>

namespace Circuit
{
    struct Vec2
    {
        float x = 0.0f;
        float y = 0.0f;
        Vec2 operator+(Vec2 v) const { return {x + v.x, y + v.y}; }
        Vec2 operator-(Vec2 v) const { return {x - v.x, y - v.y}; }
        Vec2 operator*(float s) const { return {x * s, y * s}; }
        Vec2 operator/(float s) const { return {x / s, y / s}; }
        Vec2& operator+=(Vec2 v) { x += v.x; y += v.y; return *this; }
        Vec2& operator-=(Vec2 v) { x -= v.x; y -= v.y; return *this; }
    };
    float Dot(Vec2 a, Vec2 b);
    float Length(Vec2 v);

    struct Brick
    {
        Vec2 center;
        Vec2 size;
        int hits = 1;
        int maximumHits = 1;
        unsigned int paint = 0;
        bool reflective = false;
        float flash = 0.0f;
        bool Active() const { return reflective || hits > 0; }
    };

    struct Circle
    {
        Vec2 position;
        Vec2 velocity;
        float radius = 14.0f;
        unsigned int paint = 0;
        float flash = 0.0f;
        std::array<Vec2, 12> trail{};
        std::size_t trailHead = 0;
        std::size_t trailCount = 0;
        float trailTime = 0.0f;
    };

    struct Spark
    {
        Vec2 position;
        Vec2 velocity;
        float life = 0.0f;
        float lifetime = 1.0f;
        unsigned int paint = 0;
    };

    struct Contact
    {
        Vec2 normal;
        float penetration = 0.0f;
        bool touching = false;
    };

    // These same collision functions are used by the animation and physics checks.
    Contact CircleBoxContact(const Circle& circle, const Brick& brick);
    bool ResolveBrickCollision(Circle& circle, Brick& brick);
    bool ResolveCircleCollision(Circle& first, Circle& second);
    unsigned int ResolveWalls(Circle& circle);

    class AnimationWorld
    {
    public:
        static constexpr float Width = 1000.0f;
        static constexpr float Height = 800.0f;
        static constexpr float Left = 24.0f;
        static constexpr float Right = 976.0f;
        static constexpr float Top = 92.0f;
        static constexpr float Bottom = 772.0f;
        static constexpr double FixedStep = 1.0 / 120.0;
        static constexpr std::size_t MaximumCircles = 12;

        explicit AnimationWorld(std::uint32_t seed);
        void Reset();
        void Advance(double elapsedSeconds);
        bool AddCircle();
        void TogglePause();
        void SetPaddleInput(float axis);

        const std::vector<Brick>& Bricks() const { return m_bricks; }
        const std::vector<Circle>& Circles() const { return m_circles; }
        const std::array<Spark, 320>& Sparks() const { return m_sparks; }
        const Brick& Paddle() const { return m_paddle; }
        bool Paused() const { return m_paused; }
        unsigned int BrokenBricks() const { return m_brokenBricks; }
        unsigned int CircleContacts() const { return m_circleContacts; }
        unsigned int WallContacts() const { return m_wallContacts; }
        std::size_t ActiveBricks() const;

    private:
        std::uint32_t m_seed;
        std::mt19937 m_launchRandom;
        std::mt19937 m_effectRandom;
        std::vector<Brick> m_bricks;
        std::vector<Circle> m_circles;
        std::array<Spark, 320> m_sparks{};
        std::size_t m_nextSpark = 0;
        Brick m_paddle;
        double m_accumulator = 0.0;
        float m_paddleInput = 0.0f;
        bool m_paused = false;
        unsigned int m_brokenBricks = 0;
        unsigned int m_circleContacts = 0;
        unsigned int m_wallContacts = 0;

        void BuildLayout();
        void Step(float dt);
        void PlaceCircle(Vec2 position, Vec2 direction, float radius, unsigned int paint);
        void EmitBurst(Vec2 position, unsigned int paint);
    };
}
