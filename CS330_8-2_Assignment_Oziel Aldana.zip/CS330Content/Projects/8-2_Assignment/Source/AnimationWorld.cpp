#include "AnimationWorld.h"

#include <algorithm>
#include <cmath>

namespace Circuit
{
    namespace
    {
        constexpr float Pi = 3.14159265358979323846f;
        constexpr float Separation = 0.03f;
        constexpr unsigned int PaintCount = 6;
        float Clamp(float value, float low, float high)
        {
            return std::max(low, std::min(value, high));
        }
    }

    float Dot(Vec2 a, Vec2 b) { return a.x * b.x + a.y * b.y; }
    float Length(Vec2 v) { return std::sqrt(Dot(v, v)); }

    Contact CircleBoxContact(const Circle& circle, const Brick& brick)
    {
        const Vec2 half = brick.size * 0.5f;
        const Vec2 local = circle.position - brick.center;
        const Vec2 nearest{Clamp(local.x, -half.x, half.x), Clamp(local.y, -half.y, half.y)};
        const Vec2 difference = local - nearest;
        const float squared = Dot(difference, difference);
        if (squared > circle.radius * circle.radius)
            return {};
        if (squared > 0.000001f)
        {
            const float distance = std::sqrt(squared);
            return {difference / distance, circle.radius - distance, true};
        }
        // A center inside the box must leave through its nearest face.
        const float horizontal = half.x - std::abs(local.x);
        const float vertical = half.y - std::abs(local.y);
        if (horizontal < vertical)
            return {{local.x < 0.0f ? -1.0f : 1.0f, 0.0f}, circle.radius + horizontal, true};
        return {{0.0f, local.y < 0.0f ? -1.0f : 1.0f}, circle.radius + vertical, true};
    }

    bool ResolveBrickCollision(Circle& circle, Brick& brick)
    {
        if (!brick.Active())
            return false;
        const Contact hit = CircleBoxContact(circle, brick);
        if (!hit.touching)
            return false;
        circle.position += hit.normal * (hit.penetration + Separation);
        const float incoming = Dot(circle.velocity, hit.normal);
        if (incoming >= 0.0f)
            return false;
        // Reflect only the component directed into the contacted face.
        circle.velocity -= hit.normal * (2.0f * incoming);
        circle.flash = 0.16f;
        brick.flash = 0.16f;
        if (!brick.reflective)
            --brick.hits;
        return true;
    }

    bool ResolveCircleCollision(Circle& first, Circle& second)
    {
        const Vec2 difference = second.position - first.position;
        const float reach = first.radius + second.radius;
        const float squared = Dot(difference, difference);
        if (squared > reach * reach)
            return false;
        const float distance = std::sqrt(std::max(squared, 0.0f));
        Vec2 normal{1.0f, 0.0f};
        if (distance > 0.00001f)
            normal = difference / distance;
        else
        {
            const Vec2 approach = first.velocity - second.velocity;
            if (Length(approach) > 0.00001f)
                normal = approach / Length(approach);
        }
        // Area supplies a consistent relative mass for differently sized circles.
        const float inverseFirst = 1.0f / (first.radius * first.radius);
        const float inverseSecond = 1.0f / (second.radius * second.radius);
        const float inverseSum = inverseFirst + inverseSecond;
        const float overlap = reach - distance + Separation;
        first.position -= normal * (overlap * inverseFirst / inverseSum);
        second.position += normal * (overlap * inverseSecond / inverseSum);
        const float closing = Dot(second.velocity - first.velocity, normal);
        if (closing >= 0.0f)
            return false;
        const float impulse = -2.0f * closing / inverseSum;
        first.velocity -= normal * (impulse * inverseFirst);
        second.velocity += normal * (impulse * inverseSecond);
        first.paint = (first.paint + 1) % PaintCount;
        second.paint = (second.paint + 1) % PaintCount;
        first.flash = second.flash = 0.24f;
        return true;
    }

    unsigned int ResolveWalls(Circle& circle)
    {
        unsigned int hits = 0;
        if (circle.position.x < AnimationWorld::Left + circle.radius)
        {
            circle.position.x = AnimationWorld::Left + circle.radius;
            if (circle.velocity.x < 0.0f) { circle.velocity.x = -circle.velocity.x; ++hits; }
        }
        if (circle.position.x > AnimationWorld::Right - circle.radius)
        {
            circle.position.x = AnimationWorld::Right - circle.radius;
            if (circle.velocity.x > 0.0f) { circle.velocity.x = -circle.velocity.x; ++hits; }
        }
        if (circle.position.y < AnimationWorld::Top + circle.radius)
        {
            circle.position.y = AnimationWorld::Top + circle.radius;
            if (circle.velocity.y < 0.0f) { circle.velocity.y = -circle.velocity.y; ++hits; }
        }
        if (circle.position.y > AnimationWorld::Bottom - circle.radius)
        {
            circle.position.y = AnimationWorld::Bottom - circle.radius;
            if (circle.velocity.y > 0.0f)
            {
                circle.velocity.y = -circle.velocity.y;
                circle.velocity.x *= 0.94f; // Tangential friction on the amber floor.
                ++hits;
            }
        }
        return hits;
    }

    AnimationWorld::AnimationWorld(std::uint32_t seed)
        : m_seed(seed), m_launchRandom(seed), m_effectRandom(seed ^ 0x9E3779B9u)
    {
        Reset();
    }

    void AnimationWorld::BuildLayout()
    {
        m_bricks.clear();
        const std::array<int, 6> columns{{3, 5, 7, 7, 5, 3}};
        const std::array<float, 3> widths{{70.0f, 82.0f, 94.0f}};
        const std::array<int, 6> durability{{1, 2, 3, 3, 2, 1}};
        for (std::size_t row = 0; row < columns.size(); ++row)
        {
            float total = static_cast<float>(columns[row] - 1) * 16.0f;
            for (int column = 0; column < columns[row]; ++column)
                total += widths[(static_cast<std::size_t>(column) + row) % widths.size()];
            float left = (Width - total) * 0.5f;
            for (int column = 0; column < columns[row]; ++column)
            {
                const float width = widths[(static_cast<std::size_t>(column) + row) % widths.size()];
                const float height = 28.0f + static_cast<float>(row % 3) * 3.0f;
                m_bricks.push_back({{left + width * 0.5f, 154.0f + static_cast<float>(row) * 47.0f},
                    {width, height}, durability[row], durability[row], static_cast<unsigned int>(row), false, 0.0f});
                left += width + 16.0f;
            }
        }
    }

    void AnimationWorld::PlaceCircle(Vec2 position, Vec2 direction, float radius, unsigned int paint)
    {
        Circle circle;
        circle.position = position;
        circle.velocity = direction * (235.0f / Length(direction));
        circle.radius = radius;
        circle.paint = paint % PaintCount;
        m_circles.push_back(circle);
    }

    void AnimationWorld::Reset()
    {
        m_launchRandom.seed(m_seed);
        m_effectRandom.seed(m_seed ^ 0x9E3779B9u);
        m_circles.clear();
        m_sparks.fill({});
        m_nextSpark = 0;
        m_brokenBricks = m_circleContacts = m_wallContacts = 0;
        m_accumulator = 0.0;
        m_paddleInput = 0.0f;
        m_paused = false;
        m_paddle = {{500.0f, 734.0f}, {170.0f, 18.0f}, 1, 1, 4, true, 0.0f};
        BuildLayout();
        std::uniform_real_distribution<float> pairAngle(0.38f, 0.68f);
        const float angle = pairAngle(m_launchRandom);
        // The opening pair meets early so the color-changing rule is visible.
        PlaceCircle({280, 550}, {std::cos(angle), -std::sin(angle)}, 14, 0);
        PlaceCircle({350, 550}, {-std::cos(angle), -std::sin(angle)}, 14, 1);
        std::uniform_real_distribution<float> launch(-2.65f, -0.48f);
        const std::array<Vec2, 4> starts{{{480, 665}, {655, 570}, {820, 635}, {175, 680}}};
        for (std::size_t i = 0; i < starts.size(); ++i)
        {
            const float heading = launch(m_launchRandom);
            PlaceCircle(starts[i], {std::cos(heading), std::sin(heading)},
                13.0f + static_cast<float>(i % 3) * 2.0f, static_cast<unsigned int>(i + 2));
        }
    }

    bool AnimationWorld::AddCircle()
    {
        if (m_circles.size() >= MaximumCircles)
            return false;
        std::uniform_real_distribution<float> x(90.0f, 910.0f);
        std::uniform_real_distribution<float> y(510.0f, 690.0f);
        std::uniform_real_distribution<float> angle(-2.65f, -0.48f);
        for (int attempt = 0; attempt < 32; ++attempt)
        {
            const Vec2 candidate{x(m_launchRandom), y(m_launchRandom)};
            bool clear = true;
            for (const auto& circle : m_circles)
                if (Length(circle.position - candidate) < circle.radius + 22.0f) clear = false;
            if (!clear) continue;
            const float heading = angle(m_launchRandom);
            PlaceCircle(candidate, {std::cos(heading), std::sin(heading)}, 14.0f,
                static_cast<unsigned int>(m_circles.size()));
            return true;
        }
        return false;
    }

    void AnimationWorld::TogglePause() { m_paused = !m_paused; m_accumulator = 0.0; }
    void AnimationWorld::SetPaddleInput(float axis) { m_paddleInput = Clamp(axis, -1.0f, 1.0f); }
    std::size_t AnimationWorld::ActiveBricks() const
    {
        return static_cast<std::size_t>(std::count_if(m_bricks.begin(), m_bricks.end(),
            [](const Brick& brick) { return brick.Active(); }));
    }

    void AnimationWorld::EmitBurst(Vec2 position, unsigned int paint)
    {
        std::uniform_real_distribution<float> angle(0.0f, 2.0f * Pi);
        std::uniform_real_distribution<float> speed(45.0f, 115.0f);
        std::uniform_real_distribution<float> life(0.18f, 0.42f);
        for (int i = 0; i < 8; ++i)
        {
            const float heading = angle(m_effectRandom);
            const float velocity = speed(m_effectRandom);
            const float duration = life(m_effectRandom);
            m_sparks[m_nextSpark] = {position, {std::cos(heading) * velocity, std::sin(heading) * velocity},
                duration, duration, paint};
            m_nextSpark = (m_nextSpark + 1) % m_sparks.size();
        }
    }

    void AnimationWorld::Advance(double elapsedSeconds)
    {
        if (m_paused || !std::isfinite(elapsedSeconds) || elapsedSeconds <= 0.0)
            return;
        m_accumulator += std::min(elapsedSeconds, 0.10);
        while (m_accumulator + 1e-12 >= FixedStep)
        {
            Step(static_cast<float>(FixedStep));
            m_accumulator = std::max(0.0, m_accumulator - FixedStep);
        }
    }

    void AnimationWorld::Step(float dt)
    {
        m_paddle.center.x = Clamp(m_paddle.center.x + m_paddleInput * 500.0f * dt,
            Left + m_paddle.size.x * 0.5f, Right - m_paddle.size.x * 0.5f);
        m_paddle.flash = std::max(0.0f, m_paddle.flash - dt);
        for (auto& brick : m_bricks) brick.flash = std::max(0.0f, brick.flash - dt);
        for (auto& circle : m_circles)
        {
            circle.flash = std::max(0.0f, circle.flash - dt);
            circle.position += circle.velocity * dt;
            const unsigned int wallHits = ResolveWalls(circle);
            m_wallContacts += wallHits;
            if (wallHits) EmitBurst(circle.position, circle.paint);
            for (auto& brick : m_bricks)
            {
                if (ResolveBrickCollision(circle, brick))
                {
                    EmitBurst(circle.position, brick.paint);
                    if (!brick.Active()) ++m_brokenBricks;
                }
            }
            const bool descending = circle.velocity.y > 0.0f;
            if (ResolveBrickCollision(circle, m_paddle))
            {
                if (descending && circle.position.y < m_paddle.center.y)
                {
                    const float speed = Length(circle.velocity);
                    const float offset = Clamp((circle.position.x - m_paddle.center.x) /
                        (m_paddle.size.x * 0.5f), -1.0f, 1.0f);
                    circle.velocity.x = offset * speed * 0.72f;
                    circle.velocity.y = -std::sqrt(std::max(0.0f, speed * speed - circle.velocity.x * circle.velocity.x));
                }
                EmitBurst(circle.position, m_paddle.paint);
            }
        }
        for (std::size_t i = 0; i < m_circles.size(); ++i)
            for (std::size_t j = i + 1; j < m_circles.size(); ++j)
                if (ResolveCircleCollision(m_circles[i], m_circles[j]))
                {
                    ++m_circleContacts;
                    EmitBurst((m_circles[i].position + m_circles[j].position) * 0.5f, m_circles[i].paint);
                }
        for (auto& circle : m_circles)
        {
            m_wallContacts += ResolveWalls(circle);
            circle.trailTime += dt;
            if (circle.trailTime >= 0.024f)
            {
                circle.trailTime = 0.0f;
                circle.trail[circle.trailHead] = circle.position;
                circle.trailHead = (circle.trailHead + 1) % circle.trail.size();
                circle.trailCount = std::min(circle.trailCount + 1, circle.trail.size());
            }
        }
        for (auto& spark : m_sparks)
        {
            spark.life = std::max(0.0f, spark.life - dt);
            if (spark.life > 0.0f) spark.position += spark.velocity * dt;
        }
    }
}
