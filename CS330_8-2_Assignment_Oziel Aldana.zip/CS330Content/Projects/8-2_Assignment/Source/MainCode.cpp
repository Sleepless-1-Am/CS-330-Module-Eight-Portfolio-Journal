// CS 330 Module Eight: original animation built in the provided GLFW project.
#define NOMINMAX
#define GLEW_NO_GLU
#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include "AnimationRenderer.h"
#include <cstdint>
#include <ctime>
#include <iostream>

namespace
{
    void OnKey(GLFWwindow* window,int key,int,int action,int)
    {
        if(action!=GLFW_PRESS) return; // Holding Space never spawns once per frame.
        auto* world=static_cast<Circuit::AnimationWorld*>(glfwGetWindowUserPointer(window));
        if(key==GLFW_KEY_ESCAPE) glfwSetWindowShouldClose(window,GLFW_TRUE);
        if(!world) return;
        if(key==GLFW_KEY_SPACE) world->AddCircle();
        else if(key==GLFW_KEY_P) world->TogglePause();
        else if(key==GLFW_KEY_R) world->Reset();
    }

    void ProcessInput(GLFWwindow* window,Circuit::AnimationWorld& world)
    {
        float axis=0.0f;
        if(glfwGetKey(window,GLFW_KEY_A)==GLFW_PRESS || glfwGetKey(window,GLFW_KEY_LEFT)==GLFW_PRESS) axis-=1.0f;
        if(glfwGetKey(window,GLFW_KEY_D)==GLFW_PRESS || glfwGetKey(window,GLFW_KEY_RIGHT)==GLFW_PRESS) axis+=1.0f;
        world.SetPaddleInput(axis);
    }
}

int main()
{
    if(!glfwInit())
    {
        std::cerr<<"GLFW could not initialize.\n";
        return 1;
    }
    // Retain the starter's OpenGL 2.0 compatibility drawing API.
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR,2);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR,0);
    GLFWwindow* window=glfwCreateWindow(1000,800,"CS 330 8-2 | Prism Circuit",nullptr,nullptr);
    if(!window)
    {
        std::cerr<<"The animation window could not open.\n";
        glfwTerminate();
        return 1;
    }
    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    Circuit::AnimationWorld world(static_cast<std::uint32_t>(std::time(nullptr)));
    glfwSetWindowUserPointer(window,&world);
    glfwSetKeyCallback(window,OnKey);
    std::cout<<"Prism Circuit: 30 bricks, six starting circles, four wall responses.\n"
             <<"Space: add one circle | P: pause | R: reset | A/D or arrows: paddle | Esc: close\n"
             <<"Brick pips show remaining hits; circle collisions change both colors.\n";
    double lastTime=glfwGetTime();
    while(!glfwWindowShouldClose(window))
    {
        glfwPollEvents();
        const double now=glfwGetTime();
        ProcessInput(window,world);
        world.Advance(now-lastTime);
        lastTime=now;
        int width=0,height=0;
        glfwGetFramebufferSize(window,&width,&height);
        Circuit::DrawAnimation(world,width,height);
        glfwSwapBuffers(window);
    }
    glfwDestroyWindow(window);
    glfwTerminate();
    return 0;
}
