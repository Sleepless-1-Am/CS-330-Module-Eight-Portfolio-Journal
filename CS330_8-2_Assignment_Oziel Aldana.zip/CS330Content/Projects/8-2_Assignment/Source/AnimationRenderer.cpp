#define NOMINMAX
#define GLEW_NO_GLU
#include <GL/glew.h>
#include "AnimationRenderer.h"
#include <algorithm>
#include <array>
#include <cmath>
#include <string>

namespace Circuit
{
    namespace
    {
        struct Color { float r, g, b; };
        const std::array<Color, 6> Palette{{
            {0.98f,0.65f,0.25f}, {0.99f,0.38f,0.43f}, {0.37f,0.83f,0.79f},
            {0.28f,0.62f,0.96f}, {0.68f,0.48f,0.95f}, {0.96f,0.46f,0.76f}
        }};
        const Color White{0.94f,0.98f,1.0f};
        constexpr float Pi = 3.14159265358979323846f;
        Color Mix(Color a, Color b, float t)
        {
            t=std::max(0.0f,std::min(t,1.0f));
            return {a.r+(b.r-a.r)*t,a.g+(b.g-a.g)*t,a.b+(b.b-a.b)*t};
        }
        void Ink(Color c,float alpha=1.0f) { glColor4f(c.r,c.g,c.b,alpha); }
        void Rectangle(Vec2 center,Vec2 size,Color color,float alpha=1.0f)
        {
            const Vec2 h=size*0.5f;
            Ink(color,alpha); glBegin(GL_QUADS);
            glVertex2f(center.x-h.x,center.y-h.y); glVertex2f(center.x+h.x,center.y-h.y);
            glVertex2f(center.x+h.x,center.y+h.y); glVertex2f(center.x-h.x,center.y+h.y);
            glEnd();
        }
        void Line(Vec2 a,Vec2 b,Color color,float alpha=1.0f)
        {
            Ink(color,alpha); glBegin(GL_LINES);
            glVertex2f(a.x,a.y); glVertex2f(b.x,b.y); glEnd();
        }
        void Disk(Vec2 center,float radius,Color color,float alpha=1.0f)
        {
            glBegin(GL_TRIANGLE_FAN);
            Ink(Mix(color,White,0.30f),alpha); glVertex2f(center.x,center.y);
            Ink(color,alpha);
            for(int part=0;part<=36;++part)
            {
                const float angle=2.0f*Pi*static_cast<float>(part)/36.0f;
                glVertex2f(center.x+std::cos(angle)*radius,center.y+std::sin(angle)*radius);
            }
            glEnd();
        }
        // Compact pixel glyphs remove any dependency on installed fonts or assets.
        std::array<unsigned char,7> Glyph(char c)
        {
            switch(c)
            {
            case 'A': return {{14,17,17,31,17,17,17}};
            case 'B': return {{30,17,17,30,17,17,30}};
            case 'C': return {{14,17,16,16,16,17,14}};
            case 'D': return {{30,17,17,17,17,17,30}};
            case 'E': return {{31,16,16,30,16,16,31}};
            case 'F': return {{31,16,16,30,16,16,16}};
            case 'G': return {{14,17,16,23,17,17,15}};
            case 'H': return {{17,17,17,31,17,17,17}};
            case 'I': return {{14,4,4,4,4,4,14}};
            case 'J': return {{7,2,2,2,18,18,12}};
            case 'K': return {{17,18,20,24,20,18,17}};
            case 'L': return {{16,16,16,16,16,16,31}};
            case 'M': return {{17,27,21,21,17,17,17}};
            case 'N': return {{17,25,21,19,17,17,17}};
            case 'O': return {{14,17,17,17,17,17,14}};
            case 'P': return {{30,17,17,30,16,16,16}};
            case 'Q': return {{14,17,17,17,21,18,13}};
            case 'R': return {{30,17,17,30,20,18,17}};
            case 'S': return {{15,16,16,14,1,1,30}};
            case 'T': return {{31,4,4,4,4,4,4}};
            case 'U': return {{17,17,17,17,17,17,14}};
            case 'V': return {{17,17,17,17,17,10,4}};
            case 'W': return {{17,17,17,21,21,21,10}};
            case 'X': return {{17,17,10,4,10,17,17}};
            case 'Y': return {{17,17,10,4,4,4,4}};
            case 'Z': return {{31,1,2,4,8,16,31}};
            case '0': return {{14,17,19,21,25,17,14}};
            case '1': return {{4,12,4,4,4,4,14}};
            case '2': return {{14,17,1,2,4,8,31}};
            case '3': return {{30,1,1,14,1,1,30}};
            case '4': return {{2,6,10,18,31,2,2}};
            case '5': return {{31,16,16,30,1,1,30}};
            case '6': return {{14,16,16,30,17,17,14}};
            case '7': return {{31,1,2,4,8,8,8}};
            case '8': return {{14,17,17,14,17,17,14}};
            case '9': return {{14,17,17,15,1,1,14}};
            case '/': return {{1,2,2,4,8,8,16}};
            case '|': return {{4,4,4,4,4,4,4}};
            case '-': return {{0,0,0,31,0,0,0}};
            case '=': return {{0,0,31,0,31,0,0}};
            default: return {{0,0,0,0,0,0,0}};
            }
        }
        void Text(float x,float y,const std::string& text,float scale,Color color)
        {
            Ink(color); glBegin(GL_QUADS);
            for(char c:text)
            {
                const auto glyph=Glyph(c);
                for(int row=0;row<7;++row) for(int column=0;column<5;++column)
                    if(glyph[static_cast<std::size_t>(row)] & (1 << (4-column)))
                    {
                        const float left=x+static_cast<float>(column)*scale;
                        const float top=y+static_cast<float>(row)*scale;
                        const float edge=scale*0.88f;
                        glVertex2f(left,top); glVertex2f(left+edge,top);
                        glVertex2f(left+edge,top+edge); glVertex2f(left,top+edge);
                    }
                x+=6.0f*scale;
            }
            glEnd();
        }
        void DrawBrick(const Brick& brick)
        {
            if(!brick.Active()) return;
            const Vec2 half=brick.size*0.5f;
            const float fraction=static_cast<float>(brick.hits)/static_cast<float>(brick.maximumHits);
            Color base=Mix({0.14f,0.17f,0.25f},Palette[brick.paint%Palette.size()],0.36f+0.64f*fraction);
            base=Mix(base,White,brick.flash*4.0f);
            Rectangle(brick.center+Vec2{3,4},brick.size,{0.015f,0.025f,0.05f},0.75f);
            Rectangle(brick.center,brick.size,base);
            Rectangle(brick.center-Vec2{0,half.y-2},{brick.size.x,4},Mix(base,White,0.30f));
            Rectangle(brick.center+Vec2{0,half.y-2},{brick.size.x,4},Mix(base,{0,0,0},0.24f));
            if(brick.reflective)
            {
                Line(brick.center-Vec2{half.x-15,0},brick.center+Vec2{half.x-15,0},White,0.65f);
                return;
            }
            for(int pip=0;pip<brick.hits;++pip)
                Rectangle(brick.center+Vec2{(static_cast<float>(pip)-static_cast<float>(brick.hits-1)*0.5f)*8.0f,0},{4,4},White,0.85f);
            if(brick.hits<brick.maximumHits)
            {
                const Vec2 start=brick.center-Vec2{half.x*0.50f,half.y-4};
                const Vec2 elbow=brick.center+Vec2{-half.x*0.12f,2};
                Line(start,elbow,{0.06f,0.08f,0.12f},0.8f);
                Line(elbow,brick.center+Vec2{-half.x*0.28f,half.y-3},{0.06f,0.08f,0.12f},0.8f);
            }
        }
    }

    void DrawAnimation(const AnimationWorld& world,int framebufferWidth,int framebufferHeight)
    {
        if(framebufferWidth<=0 || framebufferHeight<=0) return;
        glDisable(GL_DEPTH_TEST); glDisable(GL_TEXTURE_2D);
        glClearColor(0.025f,0.040f,0.070f,1.0f); glClear(GL_COLOR_BUFFER_BIT);
        const float scale=std::min(static_cast<float>(framebufferWidth)/AnimationWorld::Width,
            static_cast<float>(framebufferHeight)/AnimationWorld::Height);
        const int width=static_cast<int>(AnimationWorld::Width*scale);
        const int height=static_cast<int>(AnimationWorld::Height*scale);
        glViewport((framebufferWidth-width)/2,(framebufferHeight-height)/2,width,height);
        glMatrixMode(GL_PROJECTION); glLoadIdentity();
        glOrtho(0,AnimationWorld::Width,AnimationWorld::Height,0,-1,1);
        glMatrixMode(GL_MODELVIEW); glLoadIdentity();
        glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
        Rectangle({500,432},{952,680},{0.035f,0.060f,0.095f});
        for(float x=48;x<976;x+=40) Line({x,92},{x,772},{0.10f,0.20f,0.27f},0.20f);
        for(float y=112;y<772;y+=40) Line({24,y},{976,y},{0.10f,0.20f,0.27f},0.20f);
        Line({24,92},{976,92},{0.22f,0.45f,0.54f});
        Line({24,92},{24,772},{0.22f,0.45f,0.54f});
        Line({976,92},{976,772},{0.22f,0.45f,0.54f});
        Rectangle({500,773},{952,4},Palette[0]);
        Text(42,24,"PRISM CIRCUIT",3.0f,White);
        Text(394,28,"BRICKS "+std::to_string(world.ActiveBricks())+
            "  BROKEN "+std::to_string(world.BrokenBricks())+
            "  LINKS "+std::to_string(world.CircleContacts()),1.8f,{0.50f,0.77f,0.86f});
        Text(43,61,"SPACE ADD | P PAUSE | R RESET | A/D PADDLE",1.65f,{0.48f,0.62f,0.71f});
        Text(846,62,world.Paused()?"PAUSED":"RUNNING",1.7f,world.Paused()?Palette[0]:Palette[2]);
        Text(44,785,"AMBER FLOOR = FRICTION",1.2f,Palette[0]);
        Text(690,785,"CIRCLES "+std::to_string(world.Circles().size())+" / 12",1.2f,{0.48f,0.62f,0.71f});
        for(const auto& brick:world.Bricks()) DrawBrick(brick);
        DrawBrick(world.Paddle());
        for(const auto& circle:world.Circles())
        {
            const Color color=Palette[circle.paint%Palette.size()];
            for(std::size_t age=0;age<circle.trailCount;++age)
            {
                const std::size_t index=(circle.trailHead+circle.trail.size()-circle.trailCount+age)%circle.trail.size();
                const float fraction=static_cast<float>(age+1)/static_cast<float>(circle.trailCount+1);
                Disk(circle.trail[index],circle.radius*(0.22f+0.45f*fraction),color,fraction*0.20f);
            }
            Disk(circle.position,circle.radius+3.0f,color,0.13f);
            Disk(circle.position,circle.radius,Mix(color,White,circle.flash*2.7f));
            Disk(circle.position-Vec2{circle.radius*0.25f,circle.radius*0.28f},circle.radius*0.18f,White,0.75f);
        }
        glBlendFunc(GL_SRC_ALPHA,GL_ONE);
        for(const auto& spark:world.Sparks())
            if(spark.life>0.0f)
                Rectangle(spark.position,{3.0f,3.0f},Palette[spark.paint%Palette.size()],spark.life/spark.lifetime);
        glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
        if(world.ActiveBricks()==0) Text(260,450,"ALL BRICKS CLEARED - R RESTART",2.7f,White);
    }
}
