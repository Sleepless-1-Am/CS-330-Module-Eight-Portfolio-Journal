#pragma once
#include "AnimationWorld.h"

namespace Circuit
{
    // Logical coordinates and a fitted viewport keep circles round after resizing.
    void DrawAnimation(const AnimationWorld& world, int width, int height);
}
